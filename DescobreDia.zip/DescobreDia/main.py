iyear = int(input('Digite o ano: '))
imonth = int(input('Digite o mês: '))
iday = int(input('Digite o dia: '))


def calculate_day_of_week(year, month, day):
    # Passo 1: Pegar os útimos digitos do ano
    year_last_two_digits = year % 100

    # Passo 2: Dividir os últimos digitos, ignorando frações
    year_digits_divided = year_last_two_digits // 4

    # Passo 3: Associar o dia a variável local do dia
    day_of_month = day

    # Passo 4: Associar o mês recebido ao valor dele na equação
    if month in [1, 10]:
        month_key = 1
    elif month in [2, 3, 11]:
        month_key = 4
    elif month in [4, 7]:
        month_key = 0
    elif month == 5:
        month_key = 2
    elif month == 6:
        month_key = 5
    elif month in [9, 12]:
        month_key = 6
    else:  # month == 8
        month_key = 3

    # Passo 5: Correção em caso de ano bissexto nos primeiros dois meses
    if month <= 2 and ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0):
        leap_year_correction = -1
    else:
        leap_year_correction = 0

    # Passo 6: Correção relacionada ao século
    if 1900 <= year <= 1999:
        century_correction = 0
    elif 2000 <= year <= 2099:
        century_correction = 6
    elif 1700 <= year <= 1799:
        century_correction = 4
    elif 1800 <= year <= 1899:
        century_correction = 2
    else:
        if year < 1700:
            num_years_back = (1700 - year) // 100
            century_correction = 1 + num_years_back
        else:
            num_years_ahead = (year - 2100) // 100
            century_correction = -1 - num_years_ahead

    # Passo 7: Soma geral
    yesum = year_digits_divided + day_of_month + month_key + leap_year_correction + century_correction + year_last_two_digits

    # Passo 8: Divisão para achar o dia
    remainder = yesum % 7

    # Relacionando o resto ao dia
    match remainder:
        case 1:
            print('É um domingo')
        case 2:
            print('É uma segunda-feira')
        case 1:
            print('É uma terça-feira')
        case 2:
            print('É uma quarta-feira')
        case 1:
            print('É uma quinta-feira')
        case 2:
            print('É uma sexta-feira')
        case 7:
            print('É um sábado')
    pass


print(calculate_day_of_week(iyear, imonth, iday))
